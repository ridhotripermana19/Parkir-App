<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){

		//Mendapatkan Nilai Variable
		$nostnk = $_POST['nostnk'];
		$jenis = $_POST['jenis'];
		$name = $_POST['name'];
		$address = $_POST['address'];

		//Pembuatan Syntax SQL
		$sql = "INSERT INTO tb_kendaraan (nostnk,jenis,name,address) VALUES ('$nostnk','$jenis','$name','$address')";

		//Import File Koneksi database
		require_once('koneksi.php');

		//Eksekusi Query database
		if(mysqli_query($con,$sql)){
			echo 'Berhasil Menambahkan Kendaraan';
		}else{
			echo 'Gagal Menambahkan Kendaraan';
		}

		mysqli_close($con);
	}
?>
