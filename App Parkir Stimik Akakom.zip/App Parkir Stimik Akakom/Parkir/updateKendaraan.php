<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){
		//MEndapatkan Nilai Dari Variable
		$id = $_POST['id'];
		$nostnk = $_POST['nostnk'];
		$jenis = $_POST['jenis'];
		$name = $_POST['name'];
		$address = $_POST['address'];

		//import file koneksi database
		require_once('koneksi.php');

		//Membuat SQL Query
		$sql = "UPDATE tb_kendaraan SET nostnk = '$nostnk', jenis = '$jenis', name = '$name', adress = '$address' WHERE tb_kendaraan.id = $id;";

		//Meng-update Database
		if(mysqli_query($con,$sql)){
			echo 'Berhasil Update Data Kendaraan';
		}else{
			echo 'Gagal Update Data Kendaraan';
		}

		mysqli_close($con);
	}
?>
