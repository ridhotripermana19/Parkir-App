package com.example.apkuts;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;



public class TampilKendaraan extends AppCompatActivity implements View.OnClickListener{

    private EditText editTextId;
    private EditText editTextNostnk;
    private EditText editTextJenis;
    private EditText editTextName;
    private EditText editTextAddress;

    private Button buttonUpdate;
    private Button buttonDelete;

    private String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampil_kendaraan);

        Intent intent = getIntent();

        id = intent.getStringExtra(konfigurasi.VHC_ID);

        editTextId = (EditText) findViewById(R.id.editTextId);
        editTextNostnk = (EditText) findViewById(R.id.editTextNoStnk);
        editTextJenis =  (EditText) findViewById(R.id.editTextJenis);
        editTextName = (EditText) findViewById(R.id.editTextName);
        editTextAddress = (EditText) findViewById(R.id.editTextAddress);

        buttonUpdate = (Button) findViewById(R.id.buttonUpdate);
        buttonDelete = (Button) findViewById(R.id.buttonDelete);

        buttonUpdate.setOnClickListener(this);
        buttonDelete.setOnClickListener(this);

        editTextId.setText(id);

        getVehicles();
    }

    private void getVehicles(){
        class GetVehicles extends AsyncTask<Void,Void,String>{
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(TampilKendaraan.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                showVehicles(s);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(konfigurasi.URL_GET_VHC,id);
                return s;
            }
        }
        GetVehicles gv = new GetVehicles();
        gv.execute();
    }

    private void showVehicles(String json){
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(konfigurasi.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String nostnk = c.getString(konfigurasi.TAG_NOSTNK);
            String jenis = c.getString(konfigurasi.TAG_JENIS);
            String name = c.getString(konfigurasi.TAG_NAMA);
            String address = c.getString(konfigurasi.TAG_ALAMAT);

            editTextName.setText(nostnk);
            editTextJenis.setText(jenis);
            editTextName.setText(name);
            editTextAddress.setText(address);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void updateVehicles(){
        final String nostnk = editTextNostnk.getText().toString().trim();
        final String jenis = editTextJenis.getText().toString().trim();
        final String name = editTextName.getText().toString().trim();
        final String address = editTextAddress.getText().toString().trim();

        class UpdateVehicles extends AsyncTask<Void,Void,String>{
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(TampilKendaraan.this,"Updating...","Wait...",false,false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(TampilKendaraan.this,s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... params) {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put(konfigurasi.KEY_VHC_ID,id);
                hashMap.put(konfigurasi.KEY_VHC_NOSTNK,nostnk);
                hashMap.put(konfigurasi.KEY_VHC_JENIS,jenis);
                hashMap.put(konfigurasi.KEY_VHC_NAMA,name);
                hashMap.put(konfigurasi.KEY_VHC_ALAMAT,address);

                RequestHandler rh = new RequestHandler();

                String s = rh.sendPostRequest(konfigurasi.URL_UPDATE_VHC,hashMap);

                return s;
            }
        }

        UpdateVehicles uv = new UpdateVehicles();
        uv.execute();
    }

    private void deleteVehicles(){
        class DeleteVehicles extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(TampilKendaraan.this, "Updating...", "Tunggu...", false, false);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(TampilKendaraan.this, s, Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(konfigurasi.URL_DELETE_VHC, id);
                return s;
            }
        }

        DeleteVehicles dv = new DeleteVehicles();
        dv.execute();
    }

    private void confirmDeleteVehicles(){
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Apakah Kamu Yakin Ingin Menghapus Kendaraan ini?");

        alertDialogBuilder.setPositiveButton("Ya",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        deleteVehicles();
                        startActivity(new Intent(TampilKendaraan.this,TampilSemuaKendaraan.class));
                    }
                });

        alertDialogBuilder.setNegativeButton("Tidak",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                    }
                });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public void onClick(View v) {
        if(v == buttonUpdate){
            updateVehicles();
        }

        if(v == buttonDelete){
            confirmDeleteVehicles();
        }
    }
}